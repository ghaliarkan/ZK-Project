package dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import entity.MItem;
import entity.MItemPK;

public interface MItemDao extends JpaRepository<MItem, MItemPK>{

	@Query("select a from MItem a")
	
	public List<MItem> findAllItem();
}
