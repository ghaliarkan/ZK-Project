package dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import entity.MItem;
import entity.MProvince;
import entity.MProvincePK;

public interface MProvinceDao extends JpaRepository<MProvince, MProvincePK> {

	
	@Query("select a from MProvince a")
	
	public List<MProvince> findAllProvince();
}
