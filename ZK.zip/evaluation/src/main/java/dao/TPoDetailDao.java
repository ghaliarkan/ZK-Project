package dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import entity.TPoDetail;
import entity.TPoDetailPK;

public interface TPoDetailDao extends JpaRepository<TPoDetail, TPoDetailPK> {

	//AMBIL DATA BARANG
		@Query("select a, b.itemName, a.itemPrice, a.itemQty, a.subtotal from TPoDetail a, MItem b "
				+ "where a.itemId = b.itemId AND "
				+ "a.poNo = :cari")
				public List<Object[]> findPoDetail(@Param("cari")String cari);
				
		//buat save di detail bawah
		@Query("select a from TPoDetail a where a.poNo =:poNo")
		public TPoDetail findOnePoDetail(@Param("poNo")String poNo);		
}
