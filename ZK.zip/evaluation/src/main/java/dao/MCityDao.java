package dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import entity.MCity;
import entity.MCityPK;
import entity.MItem;

public interface MCityDao extends JpaRepository<MCity, MCityPK>{

	@Query("select a from MCity a")
	
	public List<MCity> findAllCity();
	
	@Query("select a, b.provName from MCity a, MProvince b  "
			+ "where a.provId = b.provId AND "
			+ "a.provId =:kodeProvinsi ")
	public List<Object[]> findKotaByProvinsi(@Param("kodeProvinsi")String kodeProvinsi);
}
