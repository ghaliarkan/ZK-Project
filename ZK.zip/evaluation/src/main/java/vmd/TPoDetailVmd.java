package vmd;

import java.util.ArrayList;
import java.util.List;

import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.Init;
import org.zkoss.bind.annotation.NotifyChange;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.Sessions;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zk.ui.util.Clients;

import dto.MCityDto;
import dto.MItemDto;
import dto.MProvinceDto;
import dto.MsupplierDto;
import dto.TPoDetailDto;
import dto.TPoDto;
import service.MCitySvc;
import service.MItemSvc;
import service.MProvinceSvc;
import service.MSupplierSvc;
import service.TPoDetailSvc;
import service.TPoSvc;



@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class TPoDetailVmd {
	
	@WireVariable
	private TPoSvc tPoSvc;
	@WireVariable
	private TPoDetailSvc tPoDetailSvc;
	@WireVariable
	private MSupplierSvc mSupplierSvc;
	@WireVariable
	private MItemSvc mItemSvc;
	@WireVariable
	private MCitySvc mCitySvc;
	@WireVariable
	private MProvinceSvc mProvinceSvc;
	
	private List<TPoDto> tPoDtos = new ArrayList<TPoDto>();
	private TPoDto tPoDto = new TPoDto();
	private List<TPoDetailDto> tPoDetailDtos = new ArrayList<TPoDetailDto>();
	private TPoDetailDto tPoDetailDto = new TPoDetailDto();
	private List<MsupplierDto> mSupplierDtos = new ArrayList<MsupplierDto>();
	private MsupplierDto mSupplierDto = new MsupplierDto();
	private List<MItemDto> mItemDtos = new ArrayList<MItemDto>();
	private MItemDto mItemDto = new MItemDto();
	private List<MCityDto> mCityDtos = new ArrayList<MCityDto>();
	private MCityDto mCityDto = new MCityDto();
	private List<MProvinceDto> mProvinceDtos = new ArrayList<MProvinceDto>();
	private MProvinceDto mProvinceDto = new MProvinceDto();
	private double hargaTotal = 0;
	private int globalDiskon = 0;
	private double totalGlobal = 0;
	private boolean popUp = false;
	private List<TPoDetailDto> tPoDetailDtosSave = new ArrayList<TPoDetailDto>();
	
	
	
	
	public List<TPoDetailDto> gettPoDetailDtosSave() {
		return tPoDetailDtosSave;
	}

	public void settPoDetailDtosSave(List<TPoDetailDto> tPoDetailDtosSave) {
		this.tPoDetailDtosSave = tPoDetailDtosSave;
	}

	public double getHargaTotal() {
		return hargaTotal;
	}

	public void setHargaTotal(double hargaTotal) {
		this.hargaTotal = hargaTotal;
	}

	public int getGlobalDiskon() {
		return globalDiskon;
	}

	public void setGlobalDiskon(int globalDiskon) {
		this.globalDiskon = globalDiskon;
	}

	public double getTotalGlobal() {
		return totalGlobal;
	}

	public void setTotalGlobal(double totalGlobal) {
		this.totalGlobal = totalGlobal;
	}

	public boolean isPopUp() {
		return popUp;
	}

	public void setPopUp(boolean popUp) {
		this.popUp = popUp;
	}

	public List<TPoDto> gettPoDtos() {
		return tPoDtos;
	}

	public void settPoDtos(List<TPoDto> tPoDtos) {
		this.tPoDtos = tPoDtos;
	}

	public TPoDto gettPoDto() {
		return tPoDto;
	}

	public void settPoDto(TPoDto tPoDto) {
		this.tPoDto = tPoDto;
	}

	public List<TPoDetailDto> gettPoDetailDtos() {
		return tPoDetailDtos;
	}

	public void settPoDetailDtos(List<TPoDetailDto> tPoDetailDtos) {
		this.tPoDetailDtos = tPoDetailDtos;
	}

	public TPoDetailDto gettPoDetailDto() {
		return tPoDetailDto;
	}

	public void settPoDetailDto(TPoDetailDto tPoDetailDto) {
		this.tPoDetailDto = tPoDetailDto;
	}

	public List<MsupplierDto> getmSupplierDtos() {
		return mSupplierDtos;
	}

	public void setmSupplierDtos(List<MsupplierDto> mSupplierDtos) {
		this.mSupplierDtos = mSupplierDtos;
	}

	public MsupplierDto getmSupplierDto() {
		return mSupplierDto;
	}

	public void setmSupplierDto(MsupplierDto mSupplierDto) {
		this.mSupplierDto = mSupplierDto;
	}

	public List<MItemDto> getmItemDtos() {
		return mItemDtos;
	}

	public void setmItemDtos(List<MItemDto> mItemDtos) {
		this.mItemDtos = mItemDtos;
	}

	public MItemDto getmItemDto() {
		return mItemDto;
	}

	public void setmItemDto(MItemDto mItemDto) {
		this.mItemDto = mItemDto;
	}

	public List<MCityDto> getmCityDtos() {
		return mCityDtos;
	}

	public void setmCityDtos(List<MCityDto> mCityDtos) {
		this.mCityDtos = mCityDtos;
	}

	public MCityDto getmCityDto() {
		return mCityDto;
	}

	public void setmCityDto(MCityDto mCityDto) {
		this.mCityDto = mCityDto;
	}

	public List<MProvinceDto> getmProvinceDtos() {
		return mProvinceDtos;
	}

	public void setmProvinceDtos(List<MProvinceDto> mProvinceDtos) {
		this.mProvinceDtos = mProvinceDtos;
	}

	public MProvinceDto getmProvinceDto() {
		return mProvinceDto;
	}

	public void setmProvinceDto(MProvinceDto mProvinceDto) {
		this.mProvinceDto = mProvinceDto;
	}

	@Init
	public void load()
	{
		tPoDto = (TPoDto) Sessions.getCurrent().getAttribute("obj");
		//setPopUp(false);
		if(tPoDto.getPoNo() != null)
		{
			mSupplierDtos = mSupplierSvc.findAllSupplier();
			mItemDtos = mItemSvc.findAllItem();
			mCityDtos = mCitySvc.findAllCity();
			mProvinceDtos = mProvinceSvc.findAllProvince();
			tPoDtos = tPoSvc.findPO();
			setHargaTotal(tPoDto.getTotal());
		}
		else
		{
			tPoDtos = tPoSvc.findPO();
			mSupplierDtos = mSupplierSvc.findAllSupplier();
			mItemDtos = mItemSvc.findAllItem();
			mCityDtos = mCitySvc.findAllCity();
			mProvinceDtos = mProvinceSvc.findAllProvince();
		}
	}
	
	@Command("back")
	public void back()
	{
		Executions.sendRedirect("/PO.zul");
	}
	
	@NotifyChange("tPoDetailDto")
	@Command("findPrice")
	public void findPrice() {
		tPoDetailDto.setItemPrice(mItemDto.getItemPrice());
	}
	
	@NotifyChange("tPoDetailDto")
	@Command("countSubTotal")
	public void coutSubTotal() {
		tPoDetailDto.setSubtotal(tPoDetailDto.getItemQty()
				* tPoDetailDto.getItemPrice());
	}
	
	@NotifyChange({"popUp", "tPoDetailDto", "mItemDto"})
	@Command("addDetail")
	public void add()
	{
		setPopUp(true);
		tPoDetailDto = new TPoDetailDto();
		mItemDto = new MItemDto();
		//Executions.sendRedirect("/TransaksiDetail.zul");
	}
	
	@Command("backDetail")
	@NotifyChange({"popUp", "tPoDetailDto", "mItemDto"})
	public void back2()
	{
		
		setPopUp(false);
		tPoDetailDto = new TPoDetailDto();
		mItemDto = new MItemDto();
	}
	
	@NotifyChange({"tPoDto","tPoDetailDto", "tPoDetailDtos", "popUp", "hargaTotal", "totalGlobal", "globalDiskon"})
	@Command("saveDetail")
	public void saveDetail()
	{
		tPoDetailDto.setItemName(mItemDto.getItemName());
		tPoDetailDto.setItemPrice(mItemDto.getItemPrice());
		tPoDetailDtos.add(tPoDetailDto);
		int total = 0;
		for(TPoDetailDto o : tPoDetailDtos)
		{
			total += o.getSubtotal();
		}
		//tPoDto.setTotal(total);
		
		int totalHarga =0;
		double jumlah = 0;
		for (TPoDetailDto o : tPoDetailDtos) {
				totalHarga += o.getSubtotal();
		}
		if(tPoDto.getDiscount()==0){
			
			setTotalGlobal(totalHarga);
			
		}else{
			
			jumlah =totalHarga-(totalHarga*tPoDto.getDiscount()/100);
			setTotalGlobal(jumlah);
		}
		tPoDto.setTotal(total);
		
		mItemDto = new MItemDto();
		tPoDetailDto = new TPoDetailDto();
		setPopUp(false);
	}
	
	@NotifyChange({"tPoDto"})
	@Command("totalGlobal")
	public void totalGlobal(){
		int totalHarga =0;
		double jumlah = 0;
		for (TPoDetailDto o : tPoDetailDtos) {
				totalHarga += o.getSubtotal();
		}
		if(tPoDto.getDiscount()==0){
			
			setTotalGlobal(totalHarga);
			
		}else{
			
			jumlah =totalHarga-(totalHarga*tPoDto.getDiscount()/100);
			setTotalGlobal(jumlah);
		}
		tPoDto.setTotal(jumlah);
		
	}
	
	@Command("save")
	public void save(){
		TPoDto findPoDto = new TPoDto();
		findPoDto = tPoSvc.findOnePO(tPoDto.getPoNo());
		
		if (findPoDto.getPoNo() == null){ 
			//CODE FOR SAVING ORDER
			tPoDto.setSupId(mSupplierDto.getSupId());
			tPoSvc.save(tPoDto);
			
			for(TPoDetailDto detailSave : tPoDetailDtosSave)
			{
				//CODE FOR SAVING DETAIL
				tPoDetailSvc.save(detailSave);
			}
			Clients.showNotification("Data berhasil disimpan", Clients.NOTIFICATION_TYPE_INFO, null, null, 1500);
			Executions.sendRedirect("/PO.zul");
		}
		else if (findPoDto.getPoNo() != null) {
			//CODE FOR UPDATING ORDER
			tPoDto.setSupId(tPoDto.getSupId());
			tPoSvc.update(tPoDto);
			
			for(TPoDetailDto detailSave : tPoDetailDtosSave)
			{
				tPoDetailSvc.save(detailSave);
			}
			Clients.showNotification("Data berhasil di update", Clients.NOTIFICATION_TYPE_INFO, null, null, 1500);
			Executions.sendRedirect("/PO.zul");
		}
	}
		
	@Command("deleteDetail")
	@NotifyChange({"tPoDetailDto", "tPoDetailDtos", "popUp", "hargaTotal"})
	public void deleteDetail(){
		tPoDetailDtos.remove(tPoDetailDto);
		int total = 0;
		for(TPoDetailDto o : tPoDetailDtos){
			total += o.getSubtotal();
		}
		setHargaTotal(total);
	}
	
	@NotifyChange({"mCityDto", "mCityDtos", "mProvinceDto"})
	@Command("findCity")
	public void findCity()
	{
		mCityDto = null;
		mCityDtos = mCitySvc.findKotaByProvinsi(mProvinceDto.getProvId());
	}
	
	@NotifyChange({"mSupplierDto", "mSupplierDtos", "mProvinceDto"})
	@Command("findCity")
	public void findAlamat()
	{
		mSupplierDto = null;
		mSupplierDtos = mSupplierSvc.findAll();
	}

}
