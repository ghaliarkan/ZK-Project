package vmd;

import java.util.ArrayList;
import java.util.List;

import org.zkoss.bind.BindUtils;
import org.zkoss.bind.annotation.Command;
import org.zkoss.bind.annotation.Init;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.Sessions;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zk.ui.util.Clients;
import org.zkoss.zul.Messagebox;
import org.zkoss.zul.Messagebox.Button;
import org.zkoss.zul.Messagebox.ClickEvent;

import dto.TPoDto;
import service.TPoSvc;

@VariableResolver(org.zkoss.zkplus.spring.DelegatingVariableResolver.class)
public class TPoVmd {
	
	@WireVariable
	private TPoSvc tPoSvc;
	
	private List<TPoDto> tPoDtos = new ArrayList<TPoDto>();
	private TPoDto tPoDto = new TPoDto();
	private String cari;
	public List<TPoDto> gettPoDtos() {
		return tPoDtos;
	}
	public void settPoDtos(List<TPoDto> tPoDtos) {
		this.tPoDtos = tPoDtos;
	}
	public TPoDto gettPoDto() {
		return tPoDto;
	}
	public void settPoDto(TPoDto tPoDto) {
		this.tPoDto = tPoDto;
	}
	public String getCari() {
		return cari;
	}
	public void setCari(String cari) {
		this.cari = cari;
	}
	
	@Init
	public void load()
	{
		tPoDtos = tPoSvc.findPO();
	}
	
	@Command("add")
	public void add()
	{
		tPoDto = new TPoDto();
		Sessions.getCurrent().setAttribute("obj", tPoDto);
		Executions.sendRedirect("/PoDetail.zul");
	}
	
	@Command("cari")
	public void cari()
	{
		List<TPoDto> tPoDto = tPoSvc.findPoBySearch(cari);
		if(tPoDto.size() > 0)
		{
			tPoDtos = tPoDto;
			BindUtils.postNotifyChange(null, null, this, "tPoDtos");
		}
		else
		{
			Messagebox.show("Data tidak ditemukan");
		}
	}
	
	@Command("edit")
	public void edit()
	{
		if(tPoDto == null)
		{
			Messagebox.show("Pilih data yang akan di edit");
		}
		else
		{
			Sessions.getCurrent().setAttribute("obj", tPoDto);
			Executions.sendRedirect("/PoDetail.zul");
		}
		
	}
	
	@Command("delete")
	public void delete()
	{
		if(tPoDto == null)
		{
			Messagebox.show("Pilih data yang akan di delete");
		}
		else
		{
			Messagebox.show("Apakah anda yakin ingin menghapus ?", "perhatian",
					new Button[] { Button.YES, Button.NO },
					Messagebox.QUESTION, Button.NO,
					new EventListener<Messagebox.ClickEvent>() {
						
						@Override
						public void onEvent(ClickEvent event) throws Exception {
							// TODO Auto-generated method stub
							if(Messagebox.ON_YES.equals(event.getName()))
							{
								tPoSvc.delete(tPoDto);
								tPoDtos.remove(tPoDto);
								BindUtils.postNotifyChange(null, null, TPoVmd.this, "tOrderDtos");;
								Clients.showNotification("Data berhasil di delete", Clients.NOTIFICATION_TYPE_INFO, null, null, 500);
								Sessions.getCurrent().setAttribute("obj", tPoDto);
								Executions.sendRedirect("/PoDetail.zul");
							}
						}
					});
		}
	}


}
