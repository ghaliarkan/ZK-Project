package main;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import dao.TpoDao;
import entity.TPo;

public class tes {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("/META-INF/spring/app-config.xml");				
		System.out.println("Success");
		
		TpoDao tPoDao = ctx.getBean(TpoDao.class);
		
		List<TPo> tPo = tPoDao.findAll();
		for(TPo o : tPo)
		{
			o.getCityId();
			o.getDiscount();
			o.getPoAddress();
			o.getPoDate();
			o.getPoExpDate();
			o.getPoNo();
			o.getPoNotes();
			o.getPoShipment();
			o.getSupId();
			o.getTotal();
		}
//		//MENAMPILKAN KE DATABASE
//		List<MstCustomer> customers = customerDao.findAll();
//		for(MstCustomer customer : customers)
//		{
//			System.out.println("Nama Customer : " + customer.getNamaCustomer());
//			System.out.println("Kode Kota : " + customer.getKodeKota());
//			System.out.println("Alamat : " + customer.getAlamatCustomer());
//			System.out.println("Email : " + customer.getEmailCustomer());
//			System.out.println("Jenis Kelamin : " + customer.getJenisKelamin());
//			System.out.println("Kode Customer : "+customer.getKodeCustomer() + "\n");
//		}
	}

}
