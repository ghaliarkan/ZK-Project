package service;

import java.util.List;

import dto.MCityDto;

public interface MCitySvc {

	public void save (MCityDto mCityDto);
	public void update(MCityDto mCityDto);
	public void delete(MCityDto mCityDto);
	public List<MCityDto> findAllCity();
	public List<MCityDto> findKotaByProvinsi(String kodeProvinsi);

}
