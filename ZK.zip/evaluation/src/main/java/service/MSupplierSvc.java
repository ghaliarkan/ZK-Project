package service;

import java.util.List;

import dto.MsupplierDto;


public interface MSupplierSvc {
	
	public void save (MsupplierDto mSupplierDto);
	public void update(MsupplierDto mSupplierDto);
	public void delete(MsupplierDto mSupplierDto);
	public List<MsupplierDto> findAllSupplier();
	public List<MsupplierDto> findAll();

}
