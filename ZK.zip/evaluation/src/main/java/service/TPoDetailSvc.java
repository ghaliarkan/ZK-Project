package service;

import java.util.List;

import dto.TPoDetailDto;

public interface TPoDetailSvc {
	public void save (TPoDetailDto tOrderDetailDto);
	public void update(TPoDetailDto tOrderDetailDto);
	public void delete(TPoDetailDto tOrderDetailDto);
	public List<TPoDetailDto> findPoDetail (String cari);
	public TPoDetailDto findOnePoDetail(String poNo);

}
