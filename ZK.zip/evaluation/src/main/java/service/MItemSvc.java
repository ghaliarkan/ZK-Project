package service;

import java.util.List;

import dto.MItemDto;


public interface MItemSvc {

	public void save (MItemDto mItemDto);
	public void update(MItemDto mItemDto);
	public void delete(MItemDto mItemDto);
	public List<MItemDto> findAllItem();
}
