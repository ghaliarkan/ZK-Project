package service;

import java.util.List;

import dto.MProvinceDto;

public interface MProvinceSvc {

	public void save (MProvinceDto mProvinceDto);
	public void update(MProvinceDto mProvinceDto);
	public void delete(MProvinceDto mProvinceDto);
	public List<MProvinceDto> findAllProvince();

}
