package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.TPoDetailDao;
import dto.TPoDetailDto;
import entity.TPoDetail;
import service.TPoDetailSvc;
@Service("tPoDetailSvc")
@Transactional
public class TPoDetailImpl implements TPoDetailSvc {

	@Autowired
	private TPoDetailDao tPoDetailDao;
	
	@Override
	public void save(TPoDetailDto tOrderDetailDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(TPoDetailDto tOrderDetailDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(TPoDetailDto tOrderDetailDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<TPoDetailDto> findPoDetail(String cari) {
		List<Object[]> tPoDetail = tPoDetailDao.findPoDetail(cari);
		List<TPoDetailDto> tPoDetailDtos = new ArrayList<>();
		for(Object[] o : tPoDetail)
		{
			TPoDetailDto tPoDetailDto = new TPoDetailDto();
			TPoDetail tPoDetails = (TPoDetail) o[0];
			String itemName = (String) o[1];
			tPoDetailDto.setItemName(itemName);
			tPoDetailDto.setItemPrice((int) o[2]);
			tPoDetailDto.setItemQty((int) o[3]);
			tPoDetailDto.setSubtotal((int) o[4]);
			tPoDetailDtos.add(tPoDetailDto);
		}
		return tPoDetailDtos;
	}

	@Override
	public TPoDetailDto findOnePoDetail(String poNo) {
		TPoDetail tPoDetail = tPoDetailDao.findOnePoDetail(poNo);
		TPoDetailDto tPoDetailDto = new TPoDetailDto();
		if(tPoDetail != null)
		{
			tPoDetailDto.setItemId(tPoDetail.getItemId());
			tPoDetailDto.setItemPrice(tPoDetail.getItemPrice());
			tPoDetailDto.setItemQty(tPoDetail.getItemQty());
			tPoDetailDto.setPoNo(tPoDetail.getPoNo());
			tPoDetailDto.setSubtotal(tPoDetail.getSubtotal());
			tPoDetailDto.setItemName(null);
		}
		return tPoDetailDto;
	}

}
