package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.MSupplierDao;
import dto.MsupplierDto;
import entity.MSupplier;
import service.MSupplierSvc;

@Service("mSupplierSvc")
@Transactional
public class MSupplierImpl implements MSupplierSvc{
	
	@Autowired
	private MSupplierDao mSupplierDao;

	@Override
	public void save(MsupplierDto mSupplierDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(MsupplierDto mSupplierDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(MsupplierDto mSupplierDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<MsupplierDto> findAllSupplier() {
		List<MSupplier> mSupplier = mSupplierDao.findAllSupplier();
		List<MsupplierDto> mSupplierDtos = new ArrayList<MsupplierDto>();//buat nyimpen
		for(MSupplier o : mSupplier)
		{
			MsupplierDto mSupplierDto = new MsupplierDto();
			mSupplierDto.setSupAddress(o.getSupAddress());
			mSupplierDto.setSupId(o.getSupId());
			mSupplierDto.setSupName(o.getSupName());
			mSupplierDtos.add(mSupplierDto);
		}
		return mSupplierDtos;
	}

	@Override
	public List<MsupplierDto> findAll() {
		List<MSupplier> mSupplier = mSupplierDao.findAll();
		List<MsupplierDto> mSupplierDtos = new ArrayList<MsupplierDto>();//buat nyimpen
		for(MSupplier o : mSupplier)
		{
			MsupplierDto mSupplierDto = new MsupplierDto();
			mSupplierDto.setSupAddress(o.getSupAddress());
			mSupplierDto.setSupId(o.getSupId());
			mSupplierDto.setSupName(o.getSupName());
			mSupplierDtos.add(mSupplierDto);
		}
		return mSupplierDtos;
	}

}
