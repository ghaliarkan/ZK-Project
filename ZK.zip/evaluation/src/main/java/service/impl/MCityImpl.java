package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.MCityDao;
import dto.MCityDto;
import entity.MCity;
import service.MCitySvc;

@Service("mCitySvc")
@Transactional
public class MCityImpl implements MCitySvc{

	@Autowired
	private MCityDao mCityDao;
	
	@Override
	public void save(MCityDto mCityDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(MCityDto mCityDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(MCityDto mCityDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<MCityDto> findAllCity() {
		List<MCity> mCity = mCityDao.findAllCity();
		List<MCityDto> mCityDtos = new ArrayList<>();//buat nyimpen
		for(MCity o : mCity)
		{
			MCityDto mCityDto = new MCityDto();
			mCityDto.setCityId(o.getCityId());
			mCityDto.setCityName(o.getCityName());
			mCityDto.setProvId(o.getProvId());
			mCityDtos.add(mCityDto);
		}
		return mCityDtos;
	}

	@Override
	public List<MCityDto> findKotaByProvinsi(String kodeProvinsi) {
		List<Object[]> mCity = mCityDao.findKotaByProvinsi(kodeProvinsi);
		List<MCityDto> mCityDtos = new ArrayList<>();
		
		for(Object[] o : mCity)
		{
			MCityDto mCityDto = new MCityDto();
			MCity City = (MCity) o[0];
			String provName = (String) o[1];
			mCityDto.setCityId(City.getCityId());
			mCityDto.setCityName(City.getCityName());
			mCityDto.setProvId(City.getProvId());
			mCityDto.setProvName(provName);
			mCityDtos.add(mCityDto);
		}
		return mCityDtos;
	}

}
