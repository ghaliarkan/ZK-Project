package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.TpoDao;
import dto.TPoDto;
import entity.TPo;
import entity.TPoPK;
import service.TPoSvc;
@Service("tPoSvc")
@Transactional
public class TPoImpl implements TPoSvc{
	
	@Autowired
	private TpoDao tPoDao;

	@Override
	public void save(TPoDto tPoDto) {
		// TODO Auto-generated method stub
		TPo tPo = new TPo();
		tPo.setCityId(tPoDto.getCityId());
		tPo.setDiscount(tPoDto.getDiscount());
		tPo.setPoAddress(tPoDto.getPoAddress());
		tPo.setPoDate(tPoDto.getPoDate());
		tPo.setPoExpDate(tPoDto.getPoExpDate());
		tPo.setPoNo(tPoDto.getPoNo());
		tPo.setPoNotes(tPoDto.getPoNotes());
		tPo.setPoShipment(tPoDto.getPoShipment());
		tPo.setSupId(tPoDto.getSupId());
		tPo.setTotal(tPoDto.getTotal());
		
	}

	@Override
	public void update(TPoDto tPoDto) {
		TPoPK tPoPK = new TPoPK();
		tPoPK.setPoNo(tPoDto.getPoNo());
		
		TPo tPo = tPoDao.findOne(tPoPK);
		tPo.setCityId(tPoDto.getCityId());
		tPo.setDiscount(tPoDto.getDiscount());
		tPo.setPoAddress(tPoDto.getPoAddress());
		tPo.setPoDate(tPoDto.getPoDate());
		tPo.setPoExpDate(tPoDto.getPoExpDate());
		tPo.setPoNo(tPoDto.getPoNo());
		tPo.setPoNotes(tPoDto.getPoNotes());
		tPo.setPoShipment(tPoDto.getPoShipment());
		tPo.setSupId(tPoDto.getSupId());
		tPo.setTotal(tPoDto.getTotal());
		tPoDao.save(tPo);
		
	}

	@Override
	public void delete(TPoDto tPoDto) {
		TPoPK tPoPK = new TPoPK();
		tPoPK.setPoNo(tPoDto.getPoNo());
		tPoDao.delete(tPoPK);
		
	}

	@Override
	public List<TPoDto> findPO() {
		List<Object[]> objects = tPoDao.findAllPO();
		List<TPoDto> tPoDtos = new ArrayList<>();
		for(Object[] o : objects)
		{
			TPoDto tPoDto = new TPoDto();
			TPo tPo = (TPo) o[0];
			String supName = (String) o[1];
			tPoDto.setCityId(tPo.getCityId());
			tPoDto.setDiscount(tPo.getDiscount());
			tPoDto.setPoAddress(tPo.getPoAddress());
			tPoDto.setPoDate(tPo.getPoDate());
			tPoDto.setPoExpDate(tPo.getPoExpDate());
			tPoDto.setPoNo(tPo.getPoNo());
			tPoDto.setPoNotes(tPo.getPoNotes());
			tPoDto.setPoShipment(tPo.getPoShipment());
			tPoDto.setSupId(tPo.getSupId());
			tPoDto.setTotal(tPo.getTotal());
			tPoDto.setSupName(supName);
			tPoDtos.add(tPoDto);
		}
		return tPoDtos;
	}

	@Override
	public TPoDto findOnePO(String poNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TPoDto> findPoBySearch(String cari) {
		List<Object[]> objects = tPoDao.findPoBySearch("%"+cari+"%");
		List<TPoDto> tPoDtos = new ArrayList<>();
		for(Object[] o : objects)
		{
			TPoDto tPoDto = new TPoDto();
			TPo tPo= (TPo) o[0];
			String supName = (String) o[1];
			tPoDto.setCityId(tPo.getCityId());
			tPoDto.setDiscount(tPo.getDiscount());
			tPoDto.setPoAddress(tPo.getPoAddress());
			tPoDto.setPoDate(tPo.getPoDate());
			tPoDto.setPoExpDate(tPo.getPoExpDate());
			tPoDto.setPoNo(tPo.getPoNo());
			tPoDto.setPoNotes(tPo.getPoNotes());
			tPoDto.setPoShipment(tPo.getPoShipment());
			tPoDto.setSupId(tPo.getSupId());
			tPoDto.setSupName(supName);
			tPoDto.setTotal(tPo.getTotal());
			tPoDtos.add(tPoDto);
		}
		return tPoDtos;
	}
	

}
