package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.MItemDao;
import dto.MItemDto;
import entity.MItem;
import service.MItemSvc;
@Service("mItemSvc")
@Transactional
public class MItemImpl implements MItemSvc {

	@Autowired
	private MItemDao mItemDao;
	@Override
	public void save(MItemDto mItemDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(MItemDto mItemDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(MItemDto mItemDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<MItemDto> findAllItem() {
		List<MItem> mItem = mItemDao.findAllItem();
		List<MItemDto> mItemDtos = new ArrayList<>();//buat nyimpen
		for(MItem o : mItem)
		{
			MItemDto mItemDto = new MItemDto();
			mItemDto.setItemId(o.getItemId());
			mItemDto.setItemName(o.getItemName());
			mItemDto.setItemPrice(o.getItemPrice());
			mItemDto.setSupId(o.getSupId());
			mItemDtos.add(mItemDto);
		}
		return mItemDtos;
	}

}
