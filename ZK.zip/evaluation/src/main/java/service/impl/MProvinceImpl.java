package service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dao.MProvinceDao;
import dto.MProvinceDto;
import entity.MProvince;
import service.MProvinceSvc;
@Service("mProvinceSvc")
@Transactional
public class MProvinceImpl implements MProvinceSvc {

	@Autowired
	private MProvinceDao mProvinceDao;
	@Override
	public void save(MProvinceDto mProvinceDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(MProvinceDto mProvinceDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(MProvinceDto mProvinceDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<MProvinceDto> findAllProvince() {
		List<MProvince> mProvince = mProvinceDao.findAllProvince();
		List<MProvinceDto> mProvinceDtos = new ArrayList<>();//buat nyimpen
		for(MProvince o : mProvince)
		{
			MProvinceDto mProvinceDto = new MProvinceDto();
			mProvinceDto.setProvId(o.getProvId());
			mProvinceDto.setProvName(o.getProvName());
			mProvinceDtos.add(mProvinceDto);
		}
		return mProvinceDtos;
	}

}
