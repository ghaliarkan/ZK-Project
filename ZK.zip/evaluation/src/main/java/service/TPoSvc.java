package service;

import java.util.List;

import dto.TPoDto;

public interface TPoSvc  {
	
	public void save (TPoDto tPoDto);
	public void update(TPoDto tPoDto);
	public void delete(TPoDto tPoDto);
	public List<TPoDto> findPO();
	public TPoDto findOnePO(String poNo);
	public List<TPoDto> findPoBySearch(String cari);

}
